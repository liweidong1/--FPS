//
//  LXTabBarController.h
//  今日头条
//
//  Created by MyOS on 17/3/15.
//  Copyright © 2017年 XXXX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LXTabBarController : UITabBarController

@end
