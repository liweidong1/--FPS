//
//  MainModel.m
//  今日头条
//
//  Created by MyOS on 17/3/15.
//  Copyright © 2017年 XXXX. All rights reserved.
//

#import "MainModel.h"

@implementation MainModel


@end
